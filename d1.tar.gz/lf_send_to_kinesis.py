import asyncio
import time

from app_source_load import main


def lambda_handler(event, context):
    start_time = time.time()
    print("Received event: \n" + str(event))

    source = event['source']
    message_type = event['message_type']
    message_count = event['message_count']

    future = asyncio.ensure_future(main(source, message_type, message_count))
    loop = asyncio.get_event_loop()
    loop.run_until_complete(future)

    print(f'done processing {event}')
    print('--- {} seconds ---'.format(time.time() - start_time))
