import asyncio
from json import dumps
from random import randint


from util import decimal_default


async def create_producer(config):
    return

async def producer_send(producer, msg, config, m_num):
    topic = config[config['brokers_to_use']]['kafka']['topic']
    try:
        producer.send(topic, value=msg)
        if config['add_delay']:
            await asyncio.sleep(randint(10, config['max_delay_ms']) / 1000)
        print(f'Wrote #{m_num} {dumps(msg, default=decimal_default)}')
    except BufferError as e:
        print(f'BufferError error {e}')
    except Exception as e:
        print(f'Caught exception {e}')
        raise


async def bound_producer(sem, producer, msg_generator, config, m_num):
    # send function with semaphore.
    async with sem:
        msg = await msg_generator.stub_message()
        await producer_send(producer, msg, config, m_num)


async def run_producer(sem, producer, msg_generator, config):
    msg_count = config['message_count']
    tasks = []
    try:
        for i in range(msg_count):
            task = asyncio.ensure_future(bound_producer(sem, producer, msg_generator, config, i))
            tasks.append(task)
        await asyncio.gather(*tasks, return_exceptions=True)
    finally:
        try:
            producer.flush()
            print('Done writing messages')
        except Exception as e:
            print(f'Caught exception {e}')
            raise
