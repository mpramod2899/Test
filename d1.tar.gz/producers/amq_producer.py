import asyncio
from json import dumps
from random import randint
import traceback

from util import decimal_default


async def create_amq_client(config):
    conf = config[config['brokers_to_use']]['amq']
    conn = stomp.Connection([(conf['host'], conf['port'])])
    conn.start()
    conn.connect()
    print(f'created AMQ Client for {conf["host"]}')
    return conn


async def producer_send(producer, msg_generator, config, m_num):
    try:
        destination = config[config['brokers_to_use']]['amq']['queue']

        msgs = await msg_generator.stub_message()
        for msg in msgs:
            msg_payload = dumps(msg, default=decimal_default)

            producer.send(body=msg_payload.encode('utf-8'),
                          destination=destination)
            if config['add_delay']:
                await asyncio.sleep(randint(10, config['max_delay_ms']) / 1000)
            print(f'Wrote #{m_num} {msg_payload}')
    except BufferError as e:
        print(f'BufferError error {e}')
    except Exception as e:
        print(f'Caught exception {e}')
        print(traceback.format_exc())
        raise


async def bound_producer(sem, producer, msg_generator, config, m_num):
    # send function with semaphore.
    async with sem:
        await producer_send(producer, msg_generator, config, m_num)


async def run_amq_client(sem, producer, msg_generator, config):
    print('Running AMQ Client')
    msg_count = config['message_count']
    tasks = []
    try:
        for i in range(msg_count):
            task = asyncio.ensure_future(bound_producer(sem, producer, msg_generator, config, i))
            tasks.append(task)

        await asyncio.gather(*tasks, return_exceptions=True)

    finally:
        try:
            producer.disconnect()
            print('Done writing messages')
        except Exception as e:
            print(f'Caught exception {e}')
            raise
