from producers.amq_producer import create_amq_client, run_amq_client
from producers.rmq_producer import create_rmq_client, run_rmq_client
from producers.kafka_producer import create_producer, run_producer
from producers.kinesis_producer import create_kinesis_producer, run_kinesis_producer


async def producer_factory(source_type, config, sem, msg_generator):
    producer_creator = await get_producer(source_type)
    data_writer = await producer_creator(config)

    producer_runner = await get_producer_runner(source_type)
    await producer_runner(sem, data_writer, msg_generator, config)


async def get_producer(source_type):
    if source_type == 'kafka':
        return create_producer
    elif source_type == 'amq':
        return create_amq_client
    elif source_type == 'rmq':
        return create_rmq_client
    elif source_type == 'kinesis':
        return create_kinesis_producer
    else:
        raise ValueError(source_type)


async def get_producer_runner(source_type):
    if source_type == 'kafka':
        return run_producer
    elif source_type == 'amq':
        return run_amq_client
    elif source_type == 'rmq':
        return run_rmq_client
    elif source_type == 'kinesis':
        return run_kinesis_producer
    else:
        raise ValueError(source_type)
