import asyncio
import ssl
import traceback
from json import dumps
from random import randint

import pika
from util import decimal_default


async def create_rmq_client(config):
    conf = config[config['brokers_to_use']]['rmq']
    credentials = pika.PlainCredentials(conf['user'], conf['pass'])
    if conf['use_ssl']:
        context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
        context.load_verify_locations(conf['cert_location'])
        ssl_options = pika.SSLOptions(context, conf['host'])
        parameters = pika.ConnectionParameters(host=conf['host'],
                                               port=conf['port'],
                                               virtual_host='/',
                                               credentials=credentials,
                                               ssl_options=ssl_options)
    else:
        parameters = pika.ConnectionParameters(host=conf['host'],
                                               port=conf['port'],
                                               virtual_host='/',
                                               credentials=credentials)
    # connection = pika.BlockingConnection(parameters)
    # channel = connection.channel()
    # channel.queue_declare(queue=conf['queue'])

    return parameters


async def producer_send(producer, msg_generator, config, m_num):
    conf = config[config['brokers_to_use']]['rmq']

    try:
        properties = pika.BasicProperties(content_type='application/json', delivery_mode=1, priority=1,
                                          content_encoding='utf-8')

        with pika.BlockingConnection(producer) as conn:
            ch = conn.channel()
            ch.queue_declare(queue=conf['queue'], durable=conf['durable'])

            messages = await msg_generator.stub_message()
            for msg in messages:
                msg_payload = dumps(msg, default=decimal_default)
                print(msg_payload)

                ch.basic_publish(exchange='',
                                 routing_key=conf['queue'],
                                 body=msg_payload.encode('utf-8'),
                                 properties=properties)

            if config['add_delay']:
                await asyncio.sleep(randint(10, config['max_delay_ms']) / 1000)
            print(f'Wrote #{m_num}')

    except BufferError as e:
        print(f'BufferError error {e}')
    except Exception as e:
        print(f'Caught exception {e}')
        print(traceback.format_exc())
        raise


async def bound_producer(sem, producer, msg_generator, config, m_num):
    # send function with semaphore.
    async with sem:
        await producer_send(producer, msg_generator, config, m_num)


async def run_rmq_client(sem, producer, msg_generator, config):
    print('Running RMQ Client')
    msg_count = config['message_count']
    tasks = []
    try:
        for i in range(msg_count):
            task = asyncio.ensure_future(bound_producer(sem, producer, msg_generator, config, i))
            tasks.append(task)

        await asyncio.gather(*tasks, return_exceptions=True)

    finally:
        print('Done writing messages')
        # try:
        #     producer.close()
        #     print('Done writing messages')
        # except Exception as e:
        #     print(f'Caught exception {e}')
        #     raise
