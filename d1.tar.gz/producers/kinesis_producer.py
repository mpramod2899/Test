import asyncio
import json
import aiobotocore

from util import decimal_default

SHARDS = 2


def wrap_record(data, shards=SHARDS):
    return {
        # newline needed here, or else Athena doesn't see separate records
        "Data": '{}\n'.format(json.dumps(data, default=decimal_default)),
        "PartitionKey": 'partition-{}'.format(len(data) % shards)
    }


async def kinesis_produce(config, records, loop=None):
    stream = config[config['message_type']]['kinesis_stream']
    shards = int(config[config['message_type']]['datastream_shards'])
    session = aiobotocore.get_session()
    async with session.create_client('kinesis',
                                     region_name=config['region_name']) as client:
        try:
            data = [wrap_record(d, shards) for d in records]
            resp = await client.put_records(Records=data, StreamName=stream)
            print(resp)

        except Exception as ex:
            print(f'Caught exception {ex}')
            raise


# Factory methods create_kinesis_producer, run_kinesis_producer
async def create_kinesis_producer(config):
    session = aiobotocore.get_session()
    return session


async def run_kinesis_producer(sem, session, msg_generator, config):
    msg_count = config['message_count']
    batch_size = config['kinesis_batch_size']
    tasks = []
    try:
        print(f'sending {msg_count} in batches of {batch_size}')
        batches = await get_chunks(msg_count, batch_size)
        print(batches)

        for batch in batches:
            records = [await msg_generator.stub_message() for _ in range(batch)]
            # print(f'stubbed messages: {records}')
            task = asyncio.ensure_future(bound_producer(sem, session, records, config))
            tasks.append(task)
        await asyncio.gather(*tasks, return_exceptions=True)
    finally:
        try:
            print('Done writing messages')
        except Exception as e:
            print(f'Caught exception {e}')
            raise


async def bound_producer(sem, session, records, config):
    # send function with semaphore.
    async with sem:
        await producer_send(session, records, config)


async def producer_send(session, records, config):
    stream = config[config['message_type']]['kinesis_stream']
    shards = int(config[config['message_type']]['datastream_shards'])
    try:
        data = [wrap_record(d, shards) for d in records]
        async with session.create_client(
                'kinesis', region_name=config['region_name']) as producer:
            resp = await producer.put_records(Records=data, StreamName=stream)
            print(resp)

    except Exception as ex:
        print(f'Caught exception {ex}')
        raise


async def get_chunks(c, n):
    if n == 0:
        return [c]
    rem = [c % n] if c % n else []
    return int(c / n) * [n] + rem
