import csv
import decimal
import os
from pathlib import Path
import yaml
from json import load

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))


async def get_config():
    with open('config.yml', 'r') as ymlfile:
        return yaml.safe_load(ymlfile)


async def get_data_template(template_file):
    file_type = Path(template_file).suffix
    if file_type == '.json':
        return await get_json_data_template(template_file)
    elif file_type == '.csv':
        return await get_csv_data_template(template_file)
    else:
        raise ValueError(file_type)


async def get_json_data_template(template_file):
    with open(template_file, 'r') as json_file:
        return load(json_file)


async def get_csv_data_template(template_file):
    with open(template_file, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        return dict(next(reader, {}))


def decimal_default(obj):
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    raise TypeError


non_url_safe = ['"', '#', '$', '%', '&', '+',
                ',', '/', ':', ';', '=', '?',
                '@', '[', '\\', ']', '^', '`',
                '{', '|', '}', '~', "'", '.']

translate_table = {ord(char): u'' for char in non_url_safe}


def slugify(text):
    text = text.translate(translate_table)
    text = u'-'.join(text.split())
    return text
