import argparse
import asyncio
import time

from data_generator.message_generator import message_generator_factory
from producers.producer_factory import producer_factory
from util import get_config


async def main(source_type=None, message_type=None, num_messages=None):
    config = await get_config()
    sem = asyncio.Semaphore(config['throughput_capacity'])
    if message_type:
        config['message_type'] = message_type
    if num_messages:
        config['message_count'] = int(num_messages)
    msg_generator = await message_generator_factory(message_type or config['message_type'], config)
    await producer_factory(source_type or config['data_source_type'], config, sem, msg_generator)
    print('Done ...')


if __name__ == '__main__':
    start_time = time.time()

    parser = argparse.ArgumentParser()
    parser.add_argument("-s",
                        "--source",
                        help="Source system to target: amq, kafka")
    parser.add_argument("-m",
                        "--message",
                        help="Message template to use: rtp_credit_transfer, request_for_payment, etc"
                             "third_party_payment_response")
    parser.add_argument("-n",
                        "--num",
                        help="number of messages to send",
                        default=10)

    args = parser.parse_args()

    loop = asyncio.get_event_loop()
    print(f'Launching source load {args.source} with message type {args.message}')
    future = asyncio.ensure_future(main(args.source, args.message, args.num))
    loop.run_until_complete(future)

    print('--- {} seconds ---'.format(time.time() - start_time))
