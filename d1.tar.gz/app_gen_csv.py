import asyncio
import csv
import time
from pathlib import Path
from random import randint

import boto3

from data_generator.message_generator import message_generator_factory
from util import get_config


async def file_upload(config, output_file: Path):
    s3 = boto3.resource('s3')
    destination = f"{config['s3_folder']}{output_file.name}"
    return s3.Bucket(config['bucket_name']).upload_file(str(output_file), destination)


async def write_output_file(config, records):
    csv_columns = list(records[0].keys())
    csv_file = config[config['message_type']]['output_file']
    print(csv_file)
    try:
        with open(csv_file, 'w') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
            writer.writeheader()
            for record in records:
                writer.writerow(record)
        return Path(csv_file)
    except IOError as exc:
        print(f"I/O error {exc}")


async def gen_file(msg_generator, config):
    fake_data = []
    for i in range(config['message_count']):
        if not(i % 100) and config['add_delay']:
            await asyncio.sleep(randint(10, config['max_delay_ms']) / 1000)
        messages = await msg_generator.stub_message()
        for m in messages:
            fake_data.append(m)
    return await write_output_file(config, fake_data)


async def main():
    config = await get_config()
    msg_generator = await message_generator_factory(config['message_type'], config)
    output_file = await gen_file(msg_generator, config)
    print(output_file)
    print('Done ...')


if __name__ == '__main__':
    start_time = time.time()
    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(main())
    loop.run_until_complete(future)

    print('--- {} seconds ---'.format(time.time() - start_time))
