from data_generator.chips_credit_transfer import ChipsCreditTransferMessageGenerator
from data_generator.daily_activity import DailyActivityMessageGenerator
from data_generator.hourly_activity import HourlyActivityMessageGenerator
from data_generator.pacs_008 import Pacs008TxMessageGenerator
from data_generator.pain_013 import Pain013MessageGenerator
from data_generator.req_for_return import ReqForReturnMessageGenerator
from data_generator.request_for_payment import RequestForPaymentMessageGenerator
from data_generator.rfp_message import RFPMessageGenerator
from data_generator.rtp_credit_transfer import RtpCreditTransferMessageGenerator
from data_generator.rtp_payment import RTPPaymentMessageGenerator
from data_generator.rtp_payment_legs import RTPPaymentLegsGenerator
from data_generator.rtp_transaction import RTPTransactionMessageGenerator
from data_generator.third_party_payment import ThirdPartyPaymentMessageGenerator
from util import get_data_template

from data_generator.rtp_tlog import RtpTLogMessageGenerator


async def message_generator_factory(message_type, config):
    template_file = config[message_type]['template_file']
    template = await get_data_template(template_file)
    print('template', template)
    if message_type == 'rtp_credit_transfer':
        return RtpCreditTransferMessageGenerator(template)
    elif message_type == 'chips_credit_transfer':
        return ChipsCreditTransferMessageGenerator(template)
    elif message_type == 'request_for_payment':
        return RequestForPaymentMessageGenerator(template)
    elif message_type == 'third_party_payment_response':
        return ThirdPartyPaymentMessageGenerator(template)
    elif message_type == 'rtp_transaction_csv':
        return RTPTransactionMessageGenerator(template)
    elif message_type == 'pacs008':
        return Pacs008TxMessageGenerator(template)
    elif message_type == 'rfp_msg':
        return RFPMessageGenerator(template)
    elif message_type == 'req_for_return_msg':
        return ReqForReturnMessageGenerator(template)
    elif message_type == 'payment_msg':
        return RTPPaymentMessageGenerator(template)
    elif message_type == 'payment_legs':
        return RTPPaymentLegsGenerator(template)
    elif message_type == 'pain013':
        return Pain013MessageGenerator(template)
    elif message_type == 'hourly_activity':
        return HourlyActivityMessageGenerator(template)
    elif message_type == 'daily_activity':
        return DailyActivityMessageGenerator(template)
    elif message_type == 'rtp_tlog':
        return RtpTLogMessageGenerator(template)
    else:
        raise ValueError(message_type)


