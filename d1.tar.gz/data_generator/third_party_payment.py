from copy import copy
from datetime import datetime
from random import randint

from data_generator.base_generator import BaseGenerator


class ThirdPartyPaymentMessageGenerator(BaseGenerator):
    async def stub_message(self):
        new_message = copy(self.template)
        now_dt_tm = datetime.now()
        new_message['RcvDtTm'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%SZ')
        new_message['MsgId'] = 'M{}021J3BJPM010{}'.format(
            now_dt_tm.strftime('%Y%m%d%H%M%S'),
            randint(10000000, 99999999)
        )
        new_message['SttlmAmt'] = self.fake.random_int(100, 10000)
        new_message['DbtrNm'] = self.fake.name()
        new_message['DbtrPstlAdrBldgNb'], new_message['DbtrPstlAdr'] = self.fake.street_address().split(' ', 1)
        new_message['DbtrPstlAdrTwnNm'] = self.fake.city()
        new_message['DbtrPstlAdrCtry'] = self.fake.country_code()
        new_message['DbtrPstlAdrPstCd'] = '{} {}'.format(self.fake.state_abbr(), self.fake.zipcode_plus4())

        return [new_message]
