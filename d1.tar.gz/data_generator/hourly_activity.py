import string
from copy import copy
from datetime import datetime
from random import choice

from data_generator.fake_providers import FakeBankProvider
from data_generator.base_generator import BaseGenerator


class HourlyActivityMessageGenerator(BaseGenerator):
    def __init__(self, template):
        super(HourlyActivityMessageGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)

    async def stub_message(self):
        new_message = copy(self.template)

        now_dt_tm = datetime.now().isoformat(' ')
        new_message['SWITCH_COMPLETED_TMSTMP'] = now_dt_tm

        new_message['TOTAL_INTBK_SETT_AMOUNT'] = self.fake.bucketed_amounts(5)  # system max is $100k
        gen_chars1 = ''.join(choice(string.ascii_uppercase) for _ in range(3))
        new_message['INSTRUCTING_BANK_CODE'] = f'00000000{gen_chars1}'
        gen_chars2 = ''.join(choice(string.ascii_uppercase) for _ in range(3))
        new_message['INSTRUCTED_BANK_CODE'] = f'00000000{gen_chars2}'
        new_message['TRANSACTION_STATUS_CODE'] = ''.join(choice(['ACCEPTED', 'REJECTED']))

        return [new_message]
