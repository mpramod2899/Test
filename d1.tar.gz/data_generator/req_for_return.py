from copy import copy
from datetime import datetime

from data_generator.fake_providers import FakeBankProvider, FakeTxProvider
from data_generator.base_generator import BaseGenerator


class ReqForReturnMessageGenerator(BaseGenerator):
    def __init__(self, template):
        super(ReqForReturnMessageGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)
        self.fake.add_provider(FakeTxProvider)

    async def stub_message(self):
        new_message = copy(self.template)
        now_dt_tm = datetime.now()
        new_message['cre_dt_tm'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S')

        rand_rfp = self.fake.pick_rand_tx()
        if rand_rfp:
            new_message['cdtr_agt_mmbid'] = rand_rfp['receiving bank']
            new_message['cdtr_acct_id'] = rand_rfp['receiving account']
            new_message['dbtr_agt_mmbid'] = rand_rfp['sending bank']
            new_message['dbtr_acct_id'] = rand_rfp['sending account']
            new_message['orig_sttlm_amt'] = rand_rfp['tx amount']
            new_message['orig_sttlm_dt'] = rand_rfp['tx date']
            new_message['orig_end_to_end_id'] = rand_rfp['end_to_end_id']
            new_message['orig_tx_id'] = rand_rfp['tx id']

        return [new_message]
