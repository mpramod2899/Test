from faker import Faker

from data_generator.fake_providers import FakeBucketedAmountProvider


class BaseGenerator:
    def __init__(self, template):
        self.template = template
        self.fake = Faker()
        self.fake.add_provider(FakeBucketedAmountProvider)

    async def stub_message(self):
        pass