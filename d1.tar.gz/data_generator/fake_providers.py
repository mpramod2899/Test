import string
from pathlib import Path
from random import randint, sample, choice, randrange

from faker.providers import BaseProvider
import pandas

BANKS_FILE_PATH = 'data/banks.txt'
ROUTING_FILE_PATH = 'data/routing.txt'
RFP_FILE_PATH = 'data/rtp/csv/output/simple_rfps.csv'
TX_FILE_PATH = 'data/rtp/csv/output/simple_payments.csv'


class FakeBucketedAmountProvider(BaseProvider):
    def __init__(self, generator):
        super().__init__(generator)
        pydecimal_fn = self.generator.provider('faker.providers.python').pydecimal
        self.amt_map = {i: lambda i=i: pydecimal_fn(left_digits=i, right_digits=2, positive=True,
                                                    min_value=10 ** i, max_value=10 ** (i + 1))
                        for i in range(10)}

    def bucketed_amounts(self, num_digits=9):
        return self.amt_map[randint(0, num_digits)]()


class FakeBankProvider(BaseProvider):
    def __init__(self, generator):
        super().__init__(generator)
        routing_numbers = self._get_sample_routing_numbers()
        num_banks = randint(10, 30)
        self.instructing_banks = self._gen_fake_banks(num_banks, routing_numbers)
        bank_names = self._get_bank_names(num_banks=50)
        self.bank_names = sample(bank_names, num_banks)

    def _gen_fake_banks(self, num_banks, routing_numbers):
        banks = {}
        bank_routing_numbers = sample(routing_numbers, num_banks)
        for bank_routing in bank_routing_numbers:
            banks[bank_routing] = [f'{randint(100000000, 999999999)}P1' for _ in range(100)]
        return banks

    def _get_sample_routing_numbers(self):
        routing_file = Path(ROUTING_FILE_PATH)
        if routing_file.exists():
            with open(routing_file, 'r') as routing_file:
                routing_numbers = [line.rstrip('\n') for line in routing_file]
        else:
            routing_numbers = [f'{randint(10000000, 999999999):09}' for _ in range(1000)]
        return routing_numbers

    def _get_bank_names(self, num_banks=50):
        bank_file = Path(BANKS_FILE_PATH)
        bank_names = []
        if bank_file.exists():
            with open(bank_file, 'r') as _file:
                bank_names = [line.rstrip('\n') for line in _file][:num_banks]
        else:
            for _ in range(num_banks):
                bank_names.append(self.fake_bank(excl=bank_names, letters_num=3))
        return bank_names

    def get_bank_names(self):
        return self.bank_names

    def pick_instructed_instructing_pair(self):
        routing_numbers = list(self.instructing_banks.keys())
        a, b = sample(routing_numbers, 2)
        return a, choice(self.instructing_banks[a]), b, choice(self.instructing_banks[b])

    def fake_bank(self, excl=None, letters_num=1):
        if excl is None:
            excl = []

        def gen_bank():
            letters = ''.join([choice(string.ascii_letters).upper() for _ in range(letters_num)])
            return f'Bank {letters}'

        bank = gen_bank()
        retries = 0
        threshold = 10
        while excl and bank in excl and retries < threshold:
            bank = gen_bank()
            retries += 1

        return bank


class FakeRefIdProvider(BaseProvider):
    def __init__(self, generator):
        super().__init__(generator)
        self.rfps = self._get_sample_refids()

    def _get_sample_refids(self):
        rfp_file = Path(RFP_FILE_PATH)
        rfps = []
        if rfp_file.exists():
            data = pandas.read_csv(RFP_FILE_PATH)
            rfps = data.to_dict(orient='records')

        return rfps

    def pick_rand_rfp(self):
        if len(self.rfps):
            return self.rfps.pop(randrange(len(self.rfps)))


class FakeTxProvider(BaseProvider):
    def __init__(self, generator):
        super().__init__(generator)
        self.txs = self._get_sample_txs()

    def _get_sample_txs(self):
        tx_file = Path(TX_FILE_PATH)
        txs = []
        if tx_file.exists():
            data = pandas.read_csv(TX_FILE_PATH)
            txs = data.to_dict(orient='records')

        return txs

    def pick_rand_tx(self):
        if len(self.txs):
            return self.txs.pop(randrange(len(self.txs)))
