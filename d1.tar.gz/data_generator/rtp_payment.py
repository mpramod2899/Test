from copy import copy
from datetime import datetime
from random import randint

from data_generator.fake_providers import FakeBankProvider, FakeRefIdProvider
from data_generator.base_generator import BaseGenerator


class RTPPaymentMessageGenerator(BaseGenerator):
    def __init__(self, template):
        super(RTPPaymentMessageGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)
        self.fake.add_provider(FakeRefIdProvider)

    # sending bank,sending account,receiving bank,receiving account,tx amount,tx date,tx time,tx type,tx status,tx id
    async def stub_message(self):
        new_message = copy(self.template)
        now_dt_tm = datetime.now()

        new_message['receiving bank'], \
        new_message['receiving account'], \
        new_message['sending bank'], \
        new_message['sending account'] = self.fake.pick_instructed_instructing_pair()

        new_message['tx date'] = now_dt_tm.strftime('%Y-%m-%d')
        new_message['tx time'] = now_dt_tm.strftime('%I:%M:%S')
        new_message['tx type'] = 'pacs.008'
        new_message['tx status'] = 'ACCT'

        new_message['tx amount'] = self.fake.bucketed_amounts(6)

        rand_rfp = self.fake.pick_rand_rfp()
        if rand_rfp:
            new_message['receiving bank'] = rand_rfp['cdtr_agt_mmbid']
            new_message['receiving account'] = rand_rfp['cdtr_acct_id']
            new_message['sending bank'] = rand_rfp['dbtr_agt_mmbid']
            new_message['sending account'] = rand_rfp['dbtr_acct_id']
            new_message['tx amount'] = rand_rfp['instd_amt']
            new_message['end_to_end_id'] = rand_rfp['end_to_end_id']

        new_message['tx id'] = '{}{}B{}{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            new_message['sending account'],
            self.fake.pystr(4, 4).upper(),
            f'{randint(1, 99999):011}'
        )

        return [new_message]
