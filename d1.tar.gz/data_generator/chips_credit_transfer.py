from copy import copy
from datetime import datetime
from random import sample, randint

from data_generator.rtp_credit_transfer import RtpCreditTransferMessageGenerator


class ChipsCreditTransferMessageGenerator(RtpCreditTransferMessageGenerator):

    async def stub_message(self):
        new_message = copy(self.template)
        now_dt_tm = datetime.now()
        new_message['BusinessDate'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
        new_message['Datetime_PaymentStored'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
        new_message['Datetime_PaymentReleasable'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
        new_message['Datetime_PaymentResolved'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]

        new_message['Sender'], new_message['Receiver'] = sample(self.fake.get_bank_names(), 2)
        new_message['Amount'] = self.fake.bucketed_amounts(7)

        new_message['dataKey'] = '{}{}B{}{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            new_message['Sender'].replace(' ', '').upper(),
            self.fake.pystr(4, 4).upper(),
            f'{randint(1, 99999):011}'
        )
        return [new_message]
