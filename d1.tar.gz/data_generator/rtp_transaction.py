from copy import copy
from datetime import datetime
from random import randint

from data_generator.fake_providers import FakeBankProvider
from data_generator.base_generator import BaseGenerator


class RTPTransactionMessageGenerator(BaseGenerator):
    def __init__(self, template):
        super(RTPTransactionMessageGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)

    async def stub_message(self):
        new_message = copy(self.template)
        now_dt_tm = datetime.now()
        new_message['creationDateTime'] = now_dt_tm.strftime('%m/%d/%Y %I:%M:%S %p')

        new_message['instructedParticipantRoutingNumber'], \
        new_message['instructedParticipantId'], \
        new_message['instructingParticipantRoutingNumber'], \
        new_message['instructingParticipantId'] = self.fake.pick_instructed_instructing_pair()

        new_message['settlementCycleDate'] = now_dt_tm.strftime('%m/%d/%Y')

        new_message['transactionAmount'] = self.fake.bucketed_amounts(6)

        new_message['transactionId'] = '{}{}B{}{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            new_message['instructingParticipantId'],
            self.fake.pystr(4, 4).upper(),
            f'{randint(1, 99999):011}'
        )
        return [new_message]
