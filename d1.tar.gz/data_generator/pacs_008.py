from copy import copy
from datetime import datetime
from random import randint, choice

from data_generator.fake_providers import FakeBankProvider
from data_generator.base_generator import BaseGenerator


class Pacs008TxMessageGenerator(BaseGenerator):
    def __init__(self, template):
        super(Pacs008TxMessageGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)

    async def stub_message(self):
        new_message = copy(self.template)
        now_dt_tm = datetime.now()
        msg_serial = f'{randint(1, 99999):011}'
        new_message['cre_dt_tm'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S')

        new_message['dbtr_agt_mmbid'], \
        new_message['dbtr_acct_id'], \
        new_message['cdtr_agt_mmbid'], \
        new_message['cdtr_acct_id'] = self.fake.pick_instructed_instructing_pair()

        new_message['instg_agt_mmbid'] = new_message['dbtr_agt_mmbid']
        new_message['instd_agt_mmbid'] = new_message['cdtr_agt_mmbid']

        new_message['msg_id'] = 'M{}{}B{}{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            new_message['instg_agt_mmbid'],
            self.fake.pystr(3, 3).upper(),
            msg_serial
        )

        new_message['intr_bk_sttlm_dt'] = now_dt_tm.strftime('%Y-%m-%d')
        new_message['clr_sys_cd'] = 'TCH'
        new_message['instr_id'] = '{}{}B{}{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            new_message['instg_agt_mmbid'],
            self.fake.pystr(4, 4).upper(),
            msg_serial
        )
        new_message['tx_id'] = new_message['instr_id']
        new_message['lcl_instrm'] = choice(['FOREIGN AFFILIATE', 'INTERMEDIARY', 'STANDARD', 'ZELLE'])
        new_message['ctgy_purp'] = choice(['BUSINESS', 'CONSUMER'])
        new_message['intr_bk_sttlm_amt'] = self.fake.bucketed_amounts(5)  # system max is $100k
        new_message['dscnt_apld_amt_tp'] = self.fake.bucketed_amounts(5)
        new_message['dscnt_apld_amt'] = self.fake.bucketed_amounts(5)

        # patching a set of boolean fields so that message conforms to schema
        new_message['ultmt_dbtr_lei'] = bool(new_message['ultmt_dbtr_lei'])
        new_message['dbtr_acct_id'] = bool(new_message['dbtr_acct_id'])
        new_message['cdtr_acct_id'] = bool(new_message['cdtr_acct_id'])
        new_message['ultmt_cdtr_lei'] = bool(new_message['ultmt_cdtr_lei'])
        new_message['instr_for_cdtr_agt_0_instr_inf'] = bool(new_message['instr_for_cdtr_agt_0_instr_inf'])
        new_message['instr_for_cdtr_agt_1_instr_inf'] = bool(new_message['instr_for_cdtr_agt_1_instr_inf'])
        new_message['instr_for_cdtr_agt_3_instr_inf'] = bool(new_message['instr_for_cdtr_agt_3_instr_inf'])

        return [new_message]
