from copy import copy
from datetime import datetime
from random import randint

from data_generator.fake_providers import FakeBankProvider
from data_generator.base_generator import BaseGenerator


class RtpCreditTransferMessageGenerator(BaseGenerator):
    def __init__(self, template):
        super(RtpCreditTransferMessageGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)

    async def stub_message(self):
        new_message = copy(self.template)
        now_dt_tm = datetime.now()
        new_message['logtime'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%SZ')
        new_message['dateSettlement'] = now_dt_tm.strftime('%Y%m%d')
        new_message['dateLocalTransaction'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
        new_message['amountSettlement'] = self.fake.bucketed_amounts()
        new_message['debbank'] = self.fake.fake_bank()
        new_message['credbank'] = self.fake.fake_bank([new_message['debbank']])
        new_message['CreDt'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
        new_message['msgid'] = 'M{}{}XAAA{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            randint(10000000000, 99999999999),
            randint(10000000000, 99999999999)
        )
        return [new_message]
