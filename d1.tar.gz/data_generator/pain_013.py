from copy import copy
from datetime import datetime
from random import randint

from data_generator.fake_providers import FakeBankProvider
from data_generator.base_generator import BaseGenerator


class Pain013MessageGenerator(BaseGenerator):
    def __init__(self, template):
        super(Pain013MessageGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)

    async def stub_message(self):
        new_message = copy(self.template)
        now_dt_tm = datetime.now()
        msg_serial = f'{randint(1, 99999):011}'
        new_message['cre_dt_tm'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S')

        dbtr_agt_mmbid, dbtr_acct_id, \
        cdtr_agt_mmbid, cdtr_acct_id = self.fake.pick_instructed_instructing_pair()

        new_message['msg_id'] = 'M{}{}B{}{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            dbtr_agt_mmbid,
            self.fake.pystr(3, 3).upper(),
            msg_serial
        )
        new_message['instd_amt'] = self.fake.bucketed_amounts(5)  # system max is $100k
        new_message['pmt_cond_amt_mod_allwd'] = bool(new_message['pmt_cond_amt_mod_allwd'])
        new_message['pmt_cond_early_pmt_allwd'] = bool(new_message['pmt_cond_early_pmt_allwd'])
        new_message['pmt_cond_grnted_pmt_reqd'] = bool(new_message['pmt_cond_grnted_pmt_reqd'])

        return [new_message]
