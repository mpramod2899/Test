from copy import copy

from data_generator.base_generator import BaseGenerator


class RequestForPaymentMessageGenerator(BaseGenerator):
    async def stub_message(self):
        new_message = copy(self.template)
        return [new_message]
