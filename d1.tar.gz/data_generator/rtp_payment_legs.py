from copy import copy
from datetime import datetime, timedelta
from random import randint
import numpy as np

from data_generator.base_generator import BaseGenerator
from data_generator.fake_providers import FakeBankProvider


class RTPPaymentLegsGenerator(BaseGenerator):
    def __init__(self, template):
        super(RTPPaymentLegsGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)

    async def stub_message(self):
        new_message = copy(self.template)

        now_dt_tm = datetime.now()
        dbtr_agt_mmbid, dbtr_acct_id, \
        cdtr_agt_mmbid, cdtr_acct_id = self.fake.pick_instructed_instructing_pair()
        msg_serial = f'{randint(1, 99999):011}'
        end_to_end_id = '{}{}{}RFP{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            dbtr_agt_mmbid,
            self.fake.pystr(3, 3).upper(),
            msg_serial
        )
        new_message['dbtr_agt_mmbid'] = dbtr_agt_mmbid
        new_message['dbtr_acct_id'] = dbtr_acct_id
        new_message['cdtr_agt_mmbid'] = cdtr_agt_mmbid
        new_message['cdtr_acct_id'] = cdtr_acct_id
        new_message['end_to_end_id'] = end_to_end_id
        tx_times = await self._generate_tx_times(now_dt_tm)
        return [
            await self.stub_leg(
                new_message,
                tx_times[l],
                l
            )
            for l in range(5)
        ]

    async def stub_leg(self, new_message, cre_dt_tm, l_no):
        leg_msg = copy(new_message)
        leg_msg['cre_dt_tm'] = cre_dt_tm.strftime('%Y-%m-%dT%H:%M:%S.%f')
        leg_msg['leg_no'] = l_no + 1

        return leg_msg

    async def _generate_tx_times(self, now_dt_tm):
        tx_times = np.random.choice([int(abs(a)) for a in np.random.normal(100, 200, 500)], 4).tolist()

        result = []
        cumsum = 0
        for milli in tx_times:
            cumsum += milli
            result.append(now_dt_tm + timedelta(milliseconds=cumsum))
        result.append(result[-1])
        return result
