from copy import copy
from datetime import datetime, timedelta
from random import randint

from data_generator.fake_providers import FakeBankProvider
from data_generator.base_generator import BaseGenerator


class RFPMessageGenerator(BaseGenerator):
    def __init__(self, template):
        super(RFPMessageGenerator, self).__init__(template)
        self.fake.add_provider(FakeBankProvider)

    async def stub_message(self):
        new_message = copy(self.template)

        now_dt_tm = datetime.now()
        msg_serial = f'{randint(1, 99999):011}'
        new_message['cre_dt_tm'] = now_dt_tm.strftime('%Y-%m-%dT%H:%M:%S')
        new_message['xpry_dt_tm'] = (now_dt_tm + timedelta(days=3)).strftime('%Y-%m-%dT%H:%M:%S')

        dbtr_agt_mmbid, dbtr_acct_id, \
        cdtr_agt_mmbid, cdtr_acct_id = self.fake.pick_instructed_instructing_pair()
        new_message['dbtr_agt_mmbid'] = dbtr_agt_mmbid
        new_message['dbtr_acct_id'] = dbtr_acct_id
        new_message['cdtr_agt_mmbid'] = cdtr_agt_mmbid
        new_message['cdtr_acct_id'] = cdtr_acct_id

        new_message['end_to_end_id'] = '{}{}{}RFP{}'.format(
            now_dt_tm.strftime('%Y%m%d'),
            dbtr_agt_mmbid,
            self.fake.pystr(3, 3).upper(),
            msg_serial
        )
        new_message['instd_amt'] = self.fake.bucketed_amounts(5)  # system max is $100k

        return [new_message]
