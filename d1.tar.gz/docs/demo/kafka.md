# Kafka Demo

## STEP 1
Connect to EC2 management instance
```shell
ssh -i ~/.ssh/MSKKeyPair.pem ec2-user@ec2-35-169-114-1.compute-1.amazonaws.com
```
> NOTE: If port 22 is blocked, use AWS Management Console to launch browser-based SSH

## STEP 2
Check if Kafka is running:
```shell
ps aux | grep kafka
```

If no Kafka processes running, do this:

a) Start Zookeeper
```shell
cd $HOME/kafka_2.12-2.2.1/
./bin/zookeeper-server-start.sh config/zookeeper.properties
```
b) Start Kafka
```shell
cd $HOME/kafka_2.12-2.2.1/
./bin/kafka-server-start.sh config/server.properties
```

## STEP 3
Check if Kafka topic `ddu-sample-topic` exists:
```shell
cd $HOME/kafka_2.12-2.2.1/
./bin/kafka-topics.sh --list --bootstrap-server localhost:9092
```

If topic is missing, do this:
```shell
cd $HOME/kafka_2.12-2.2.1/
./bin/kafka-topics.sh --create --bootstrap-server localhost:9092 --replication-factor 1 --partitions 1 --topic ddu-sample-topic
```

## STEP 4
Start screen for Kafka consumer:
```shell
screen
```

Next, do this:
```shell
cd $HOME/github/ddu/apps/consumer_py/
source venv/bin/activate
pip install -r requirements.txt
python3 app_load_kinesis.py
```
> NOTE: To detach screen, press Ctrl A + Ctrl D sequencially.
To return back into screen, run `screen -r [REPLACE_WITH_ID]`

## STEP 5
Start script for Kafka data loader:
```shell
cd $HOME/github/ddu/apps/consumer_py/
python3 app_load_kafka.py
```

## STEP 6
When you are done with demo, clean up Kafka topic `ddu-sample-topic`:
```shell
cd $HOME/kafka_2.12-2.2.1/
./bin/kafka-topics.sh --delete --bootstrap-server localhost:9092 --topic ddu-sample-topic
```
