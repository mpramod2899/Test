# AMQ Demo

## STEP 1
Connect to EC2 management instance (make sure to obtain a copy of MSKKeyPair.pem)
```shell
ssh -i ~/.ssh/MSKKeyPair.pem ec2-user@ec2-35-169-114-1.compute-1.amazonaws.com
```
> NOTE: If port 22 is blocked, use AWS Management Console to launch browser-based SSH

## STEP 2 
Setup AMQ in a Docker container

Check if any Docker images are running:
```shell
sudo docker ps
```

If docker is not installed:
```shell
sudo yum install docker && sudo service docker start
```

For this demo we'll use an amq image from dockerhub:
```shell
sudo docker pull webcenter/activemq
```

Once the images is downloaded, start a new container by running
```shell
sudo docker run -d --name='activemq' --rm \
    -e 'ACTIVEMQ_CONFIG_MINMEMORY=512' \
    -e 'ACTIVEMQ_CONFIG_MAXMEMORY=2048'\
    -p 61616:61616 -p 61613:61613  -p 8161:8161 \
    webcenter/activemq:latest
```

Verify the container is up by running ```sudo docker ps``` one more time

## STEP 3
Setup a new queue `ddu-sample-q`:

a) Open AMQ admin console: 
<http://localhost:8161/admin>

> Note: By default, you can access the web console with `admin/admin` credentials.

b) Go to the `Queues` page and create `ddu-sample-q` queue, if it's not already there 
 

## STEP 4
Start screen for Kafka consumer:
```shell
screen
```

Next, do this:
```shell
cd $HOME/github/ddu/apps/consumer_py/
source venv/bin/activate
pip install -r requirements.txt
python3 app_load_kinesis.py
```
> NOTE: To detach screen, press Ctrl A + Ctrl D sequentially.
To return back into screen, run `screen -r [REPLACE_WITH_ID]`

## STEP 5
Start script for AMQ data loader:
```shell
cd $HOME/github/ddu/apps/consumer_py/
python3 app_source_load.py -s amq -m rtp_credit_transfer
```

## STEP 6
When you are done with demo, stop AMQ container:
```shell
sudo docker stop $(sudo docker ps -a -q --filter ancestor=webcenter/activemq --format="{{.ID}}")
```
