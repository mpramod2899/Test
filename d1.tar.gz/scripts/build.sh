#!/bin/sh

cd "$(dirname "$0")/.." || exit

DIST_FOLDER_PATH="../../build/data_ingestion"
if [ -d "${DIST_FOLDER_PATH}" ]; then
  echo "[INFO]: Removing existing build folder ${DIST_FOLDER_PATH}"
  rm -rf "${DIST_FOLDER_PATH}"
fi

if [ -f venv ]; then
  rm -rf venv
fi

python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

DEPENDENCIES="yaml wrapt attr async_timeout idna multidict yarl chardet aiohttp typing_extensions.py aioitertools jmespath six.py dateutil urllib3 docutils botocore aiobotocore s3transfer boto3 text_unidecode faker date_range.py"
PY_FILES="consumers data_generator producers data lf_send_to_kinesis.py app_source_load.py util.py config.yml"
mkdir -p "${DIST_FOLDER_PATH}" || true && \
cp -R ${PY_FILES} ${DIST_FOLDER_PATH}/

FIND=$(find venv/lib -name "python3.*" -type d -print)
if [ ! -z "${FIND}" ] ; then
  cd ${FIND}/site-packages && \
  cp -R ${DEPENDENCIES} ../../../../${DIST_FOLDER_PATH}/ && \
  cd -
else
  echo >&2 '[WARN]: Could not find any "python3.*" folder in "venv/lib/" path...'
fi

deactivate
