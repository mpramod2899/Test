import json
import time
from copy import copy


async def create_consumer(config):
   return

async def consume(consumer, config, consumer_fn):
    try:
        # Consume messages
        records = []
        started = time.time()

        while True:
            # Response format is {TopicPartition('topic1', 1): [msg1, msg2]}
            msg_pack = consumer.poll(timeout_ms=500)

            for tp, messages in msg_pack.items():
                for message in messages:
                    # print("\nConsumed topic: ", tp.topic,
                    #       "\nPartition: ", tp.partition,
                    #       "\nOffset: ", message.offset,
                    #       "\nKey: ", message.key,
                    #       "\nValue: ", message.value,
                    #       "\nTimestamp: ", message.timestamp)

                    records.append(message.value)

                    if len(records) > 1000 or time.time() - started > 2:
                        print(f'writing {len(records)} records to Kinesis DataStream')
                        records, started = await write_to_datastream(config, consumer_fn, records)

            if records:
                print(f'writing remaining {len(records)} records to Kinesis DataStream')
                records, started = await write_to_datastream(config, consumer_fn, records)

    except KeyboardInterrupt:
        print('Exiting...')

    except Exception as e:
        print(f'Caught exception {e}')

    finally:
        # Will leave consumer group; perform autocommit if enabled.
        consumer.close()


async def write_to_datastream(config, consumer_fn, records):
    await consumer_fn(config, records)
    return [], time.time()
