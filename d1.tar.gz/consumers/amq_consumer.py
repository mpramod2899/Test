import collections
import traceback
from json import loads


async def create_amq_consumer(config):
   return


async def consume_amq(config, consumer, consumer_fn):
    try:
        batch_size = 500

        while True:
            records = consumer.pull_messages(batch_size)

            if records:
                print(f'writing {len(records)} records to Kinesis DataStream')
                await consumer_fn(config, records)
    except KeyboardInterrupt:
        print('Exiting...')

    except Exception as e:
        print(f'Caught exception {e}')
        print(traceback.format_exc())
