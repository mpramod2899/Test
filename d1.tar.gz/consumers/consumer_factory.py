from consumers.amq_consumer import create_amq_consumer, consume_amq
from consumers.kafka_consumer import create_consumer, consume


async def consumer_factory(config, consumer_fn, loop):
    consumer_creator = await get_consumer(config['data_source_type'])
    consumer_runner = await get_consumer_runner(config['data_source_type'])
    await consumer_runner(config, consumer_creator, consumer_fn)


async def get_consumer(data_source_type):
    if data_source_type == 'kafka':
        return create_consumer
    elif data_source_type == 'amq':
        return create_amq_consumer
    else:
        raise ValueError(data_source_type)


async def get_consumer_runner(data_source_type):
    if data_source_type == 'kafka':
        return run_kafka_consumer
    elif data_source_type == 'amq':
        return run_amq_consumer
    else:
        raise ValueError(data_source_type)


async def run_amq_consumer(config, consumer_creator, consumer_fn):
    cn = None
    try:
        cn = await consumer_creator(config)
        consumer = cn.get_listener('amq_listener')
        await consume_amq(config, consumer, consumer_fn)

    except Exception as e:
        print(f'Caught exception {e}')

    finally:
        cn.disconnect()


async def run_kafka_consumer(config, consumer_creator, consumer_fn, *args):
    consumer = await consumer_creator(config)
    await consume(consumer, config, consumer_fn)
