SELECT 
	dataKey, 
	BusinessDate,
	Sender,
	Receiver,
	Amount,
	SSN,
	ProdSSN,
	Datetime_PaymentStored,
	Datetime_PaymentReleasable,
	Datetime_PaymentResolved,
	Delay_Release_in_Seconds,
	ISN,
	RSN,
	OSN,
	Indicator_Resolved,
	Type_Beneficiary,
	Indicator_QualifiedSend,
	Indicator_QualifiedReceive,
	BusinessPurpose,
	Flag_CurrentPreference,
	Flag_Reroute,
	RerouteSender,
	RerouteReceiver,
	Indicator_Synthetic_Payment,
	Loaddate,
CASE
 	WHEN Amount >= 500000000 THEN 'G1'
 	WHEN Amount >= 100000000 THEN 'G2'
 	WHEN Amount >=  50000000 THEN 'G3'
 	WHEN Amount >=  10000000 THEN 'G4'
 	WHEN Amount >=   1000000 THEN 'G5'
 	WHEN Amount <    1000000 THEN 'G6'
END as PaymentTranch
FROM payment_data
WHERE
	1=1
	AND BusinessDate = ''

