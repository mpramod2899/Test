SELECT 
	dateSettlement,
	dateLocalTransaction,
	debbank,
	credbank,
	amountSettlement,
	logtime,
CASE
 	WHEN amountSettlement >= 500000000 THEN 'G1'
 	WHEN amountSettlement >= 100000000 THEN 'G2'
 	WHEN amountSettlement >=  50000000 THEN 'G3'
 	WHEN amountSettlement >=  10000000 THEN 'G4'
 	WHEN amountSettlement >=   1000000 THEN 'G5'
 	WHEN amountSettlement <    1000000 THEN 'G6'
END as paymentTranch
FROM rpt_credit_transfer
WHERE
	1=1
	AND dateSettlement = '20191030'

