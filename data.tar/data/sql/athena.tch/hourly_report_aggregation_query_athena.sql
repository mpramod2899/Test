SELECT INSTRUCTING_BANK_CODE,
         INSTRUCTED_BANK_CODE,
         year,
         month,
         day,
         hour,
         ROUND( SUM(case WHEN TRANSACTION_STATUS_CODE = 'ACCEPTED' 
                 THEN TOTAL_INTBK_SETT_AMOUNT
                 ELSE 0 end), 2) AS ACCEPTED_TOTAL,
         COUNT(TOTAL_INTBK_SETT_AMOUNT) AS VOLUME_TOTAL
FROM tch.hourly_activity
GROUP BY  INSTRUCTING_BANK_CODE, INSTRUCTED_BANK_CODE, year, month, day, hour
HAVING year = '2020' AND month = '08'
ORDER BY  year, month, day, hour, INSTRUCTING_BANK_CODE, INSTRUCTED_BANK_CODE