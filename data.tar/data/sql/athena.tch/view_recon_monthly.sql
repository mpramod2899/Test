    SELECT
        SUM("number of inward transactions") AS Payment_Volume
        ,SUM("value of inward transactions") / 1000000 AS Payment_Value_mil
        ,SUM("value of inward transactions")/SUM("number of inward transactions") AS Avg_Txn_Amount
        ,Recon.year
        ,Recon.month
    FROM
        "tch"."participant_recon" AS Recon
    GROUP BY
        Recon.year, Recon.month;