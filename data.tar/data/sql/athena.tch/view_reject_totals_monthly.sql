    SELECT
        SUM("total number of cr transfer transactions rejected-outward") AS Payment_Rejects
        ,rejectTotals.year
        ,rejectTotals.month
    FROM
        "tch"."participant_reject_totals" AS rejectTotals
    GROUP BY
        rejectTotals.year, rejectTotals.month;