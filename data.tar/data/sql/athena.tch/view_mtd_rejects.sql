WITH
Dates AS (
    SELECT * FROM "tch"."view_batch_dates" limit 1
),
MTD_Rejects AS (
    SELECT
        CONCAT(
            'MTD: '
            , cast(Recon_Monthly.year as varchar(4))
            , '-'
            , cast(Recon_Monthly.month as varchar(2))) as Date_Label
        ,Recon_Monthly.Payment_Volume
        ,Recon_Monthly.Payment_Value_mil
        ,Recon_Monthly.Avg_Txn_Amount
        ,10000 * Reject_Totals_Monthly.Payment_Rejects / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Payment_Reject_Rate_Bps
        ,10000 * (R9910 + R9912 + DUPL + AM04) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Sending_To_Receiver_Bps
        ,10000 * (AG01 + AG03 + NARR + R1100 + DS24) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Receiving_Participant_Bps
        ,10000 * (Reject_Totals_Monthly.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24)) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Account_Issue_Bps
        ,Reject_Totals_Monthly.Payment_Rejects
        ,R9910 + R9912 + DUPL + AM04 AS Sending_To_Receiver
        ,R9910
        ,R9912
        ,DUPL
        ,AM04
        ,AG01 + AG03 + NARR + R1100 + DS24 AS Recieving_Participant
        ,AG01
        ,AG03
        ,NARR
        ,R1100
        ,DS24
        ,AC03 + AC04 + AC06 + AC07 AS Account_Issue
        ,AC03
        ,AC04
        ,AC06
        ,AC07
        ,Reject_Totals_Monthly.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24 + AC03 + AC04 + AC06 + AC07) AS All_Other
    FROM
        View_Code_Stats_Monthly AS Code_Stats_Monthly
        LEFT JOIN Dates
            ON 1 = 1
        INNER JOIN View_Recon_Monthly AS Recon_Monthly
            ON Code_Stats_Monthly.year = Recon_Monthly.year
            AND Code_Stats_Monthly.month = Recon_Monthly.month
        INNER JOIN View_Reject_Totals_Monthly AS Reject_Totals_Monthly
            ON Code_Stats_Monthly.year = Reject_Totals_Monthly.year
            AND Code_Stats_Monthly.month = Reject_Totals_Monthly.month
    WHERE
        Code_Stats_Monthly.year = Dates.c_year
        AND Code_Stats_Monthly.month = Dates.c_month
)

SELECT * FROM MTD_Rejects