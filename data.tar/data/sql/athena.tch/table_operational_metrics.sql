CREATE EXTERNAL TABLE `operational_metrics`(
  `id` string,
  `status` string,
  `status_dt` string,
  `batch_date` string)
ROW FORMAT SERDE
  'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe'
STORED AS INPUTFORMAT
  'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  's3://s3b-use1-dinfra-data-lake/tch-rtp-data/daily-reject-dashboard/operational_metrics'
TBLPROPERTIES (
  'transient_lastDdlTime'='1595879585')