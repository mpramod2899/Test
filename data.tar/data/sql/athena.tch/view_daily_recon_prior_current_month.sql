SELECT
  "sum"("number of inward transactions") "Payment_Volume"
, ("sum"("value of inward transactions") / 1000000) "Payment_Value_mil"
, "Recon"."year"
, "Recon"."month"
, "Recon"."day"
FROM
  tch.participant_recon "Recon"
GROUP BY "Recon"."year", "Recon"."month", "Recon"."day"
