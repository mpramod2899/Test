WITH
Dates AS (
    SELECT * FROM "tch"."view_batch_dates" limit 1
),
Code_Stats_Daily AS (
    SELECT
        SUM(IF(reject_code ='AG01',outward,0)) AS AG01
        ,SUM(IF(reject_code ='AG03',outward,0)) AS AG03
        ,SUM(IF(reject_code ='NARR',outward,0)) AS NARR
        ,SUM(IF(reject_code ='1100',outward,0)) AS R1100
        ,SUM(IF(reject_code ='DS24',outward,0)) AS DS24
        ,SUM(IF(reject_code ='AC03',outward,0)) AS AC03
        ,SUM(IF(reject_code ='AC04',outward,0)) AS AC04
        ,SUM(IF(reject_code ='AC06',outward,0)) AS AC06
        ,SUM(IF(reject_code ='AC07',outward,0)) AS AC07
        ,SUM(IF(reject_code ='OTHER',outward,0)) AS All_Other
        ,SUM(IF(reject_code ='9912',outward,0)) AS R9912
        ,SUM(IF(reject_code ='9910',outward,0)) AS R9910
        ,SUM(IF(reject_code ='AM04',outward,0)) AS AM04
        ,SUM(IF(reject_code ='DUPL',outward,0)) AS DUPL
        ,year
        ,month
        ,day
    FROM (
        SELECT
            rejectCodes."reject code" AS reject_code,
            rejectCodes.outward,
            rejectCodes.year,
            rejectCodes.month,
            rejectCodes.day
        FROM "tch"."participant_reject_codes" AS rejectCodes
            LEFT JOIN Dates
            ON 1 = 1
        WHERE
            rejectCodes.year = Dates.c_year
            AND rejectCodes.month = Dates.c_month
            AND rejectCodes.day = Dates.c_day
            AND rejectCodes."reject code" IN (
                'DUPL','9912' ,'9910','AM04','AG01','AG03','NARR', '1100',
                'DS24','AC03','AC04','AC06','AC07','OTHER'
            )
    )
    GROUP BY year, month, day
),
Recon_Daily AS (
    SELECT
        SUM("number of inward transactions") AS Payment_Volume
        ,SUM("value of inward transactions") / 1000000 AS Payment_Value_mil
        ,SUM("value of inward transactions") / SUM("number of inward transactions") AS Avg_Txn_Amount
        ,Recon.year
        ,Recon.month
        ,Recon.day
    FROM
        "tch"."participant_recon" AS Recon
        LEFT JOIN Dates
            ON 1 = 1
    WHERE
        Recon.year = Dates.c_year
        AND Recon.month = Dates.c_month
        AND Recon.day = Dates.c_day
    GROUP BY
        Recon.year, Recon.month, Recon.day
),
Reject_Totals_Daily AS (
    SELECT
        SUM("total number of cr transfer transactions rejected-outward") AS Payment_Rejects
        ,rejectTotals.year
        ,rejectTotals.month
        ,rejectTotals.day
    FROM
        "tch"."participant_reject_totals" AS rejectTotals
        LEFT JOIN Dates
            ON 1 = 1
    WHERE
        rejectTotals.year = Dates.c_year
        AND rejectTotals.month = Dates.c_month
        AND rejectTotals.day = Dates.c_day
    GROUP BY
        rejectTotals.year, rejectTotals.month, rejectTotals.day
),
Daily_Rejects AS (
    SELECT
        CONCAT(
            cast(Recon_Daily.year as varchar(4))
            , '-'
            ,cast(Recon_Daily.month as varchar(2))
            , '-'
            ,cast(Recon_Daily.day as varchar(2))) as Date_Label
        ,Recon_Daily.Payment_Volume
        ,Recon_Daily.Payment_Value_mil
        ,Recon_Daily.Avg_Txn_Amount
        ,10000 * Reject_Totals_Daily.Payment_Rejects / (Recon_Daily.Payment_Volume + Reject_Totals_Daily.Payment_Rejects) AS Payment_Reject_Rate_Bps
        ,10000 * (R9910 + R9912 + DUPL + AM04) / (Recon_Daily.Payment_Volume + Reject_Totals_Daily.Payment_Rejects) AS Sending_To_Receiver_Bps
        ,10000 * (AG01 + AG03 + NARR + R1100 + DS24) / (Recon_Daily.Payment_Volume + Reject_Totals_Daily.Payment_Rejects) AS Receiving_Participant_Bps
        ,10000 * (Reject_Totals_Daily.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24)) / (Recon_Daily.Payment_Volume + Reject_Totals_Daily.Payment_Rejects) AS Account_Issue_Bps
        ,Reject_Totals_Daily.Payment_Rejects
        ,R9910 + R9912 + DUPL + AM04 AS Sending_To_Receiver
        ,R9910
        ,R9912
        ,DUPL
        ,AM04
        ,AG01 + AG03 + NARR + R1100 + DS24 AS Recieving_Participant
        ,AG01
        ,AG03
        ,NARR
        ,R1100
        ,DS24
        ,AC03 + AC04 + AC06 + AC07 AS Account_Issue
        ,AC03
        ,AC04
        ,AC06
        ,AC07
        ,Reject_Totals_Daily.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24 + AC03 + AC04 + AC06 + AC07) AS All_Other
    FROM
        Code_Stats_Daily
        INNER JOIN Recon_Daily
            ON Code_Stats_Daily.year = Recon_Daily.year
            AND Code_Stats_Daily.month = Recon_Daily.month
            AND Code_Stats_Daily.day = Recon_Daily.day
        INNER JOIN Reject_Totals_Daily
            ON Code_Stats_Daily.year = Reject_Totals_Daily.year
            AND Code_Stats_Daily.month = Reject_Totals_Daily.month
            AND Code_Stats_Daily.day = Reject_Totals_Daily.day
)
SELECT * FROM Daily_Rejects