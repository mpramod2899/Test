WITH
s_Dates AS (
    SELECT '2020' AS c_year  , '06' AS c_month , '21' AS c_day , '2020' AS p_year , '05' AS p_month
),

Dates AS (
SELECT
     "batch_date"
   , ("batch_date" - INTERVAL  '1' DAY) "business_date"
   , (("batch_date" - INTERVAL  '1' DAY) - INTERVAL  '1' MONTH) "prior_month_date"
   , year(("batch_date" - INTERVAL  '1' DAY) ) "c_year"
   , month(("batch_date" - INTERVAL  '1' DAY) ) "c_month"
   , day(("batch_date" - INTERVAL  '1' DAY) ) "c_day"
   , year(("batch_date" - INTERVAL  '1' DAY) - INTERVAL  '1' MONTH) "p_year"
   , month(("batch_date" - INTERVAL  '1' DAY) - INTERVAL  '1' MONTH) "p_month"
   , id
   , status
   , status_dt
   FROM
     tch.operational_metrics
   WHERE ("status" = 'FILE_UPLOADED')
    AND (id like '%Participant_Reconciliation_Report_Operator_%')
   ORDER BY "batch_date" DESC
),

Code_Stats_Daily AS (
    SELECT
        SUM(IF(reject_code ='AG01',outward,0)) AS AG01
        ,SUM(IF(reject_code ='AG03',outward,0)) AS AG03
        ,SUM(IF(reject_code ='NARR',outward,0)) AS NARR
        ,SUM(IF(reject_code ='1100',outward,0)) AS R1100
        ,SUM(IF(reject_code ='DS24',outward,0)) AS DS24
        ,SUM(IF(reject_code ='AC03',outward,0)) AS AC03
        ,SUM(IF(reject_code ='AC04',outward,0)) AS AC04
        ,SUM(IF(reject_code ='AC06',outward,0)) AS AC06
        ,SUM(IF(reject_code ='AC07',outward,0)) AS AC07
        ,SUM(IF(reject_code ='OTHER',outward,0)) AS All_Other
        ,SUM(IF(reject_code ='9912',outward,0)) AS R9912
        ,SUM(IF(reject_code ='9910',outward,0)) AS R9910
        ,SUM(IF(reject_code ='AM04',outward,0)) AS AM04
        ,SUM(IF(reject_code ='DUPL',outward,0)) AS DUPL
        ,year
        ,month
        ,day
    FROM (
        SELECT
            rejectCodes."reject code" AS reject_code,
            rejectCodes.outward,
            rejectCodes.year,
            rejectCodes.month,
            rejectCodes.day
        FROM "tch"."participant_reject_codes" AS rejectCodes
            LEFT JOIN Dates
            ON 1 = 1
        WHERE
            rejectCodes.year = Dates.c_year
            AND rejectCodes.month = Dates.c_month
            AND rejectCodes.day = Dates.c_day
            AND rejectCodes."reject code" IN (
                'DUPL','9912' ,'9910','AM04','AG01','AG03','NARR', '1100',
                'DS24','AC03','AC04','AC06','AC07','OTHER'
            )
    )
    GROUP BY year, month, day
),

Code_Stats_Monthly AS (
    SELECT
         SUM(IF(reject_code = 'AG01',outward,0)) AS AG01
        ,SUM(IF(reject_code = 'AG03',outward,0)) AS AG03
        ,SUM(IF(reject_code = 'NARR',outward,0)) AS NARR
        ,SUM(IF(reject_code = '1100',outward,0)) AS R1100
        ,SUM(IF(reject_code = 'DS24',outward,0)) AS DS24
        ,SUM(IF(reject_code = 'AC03',outward,0)) AS AC03
        ,SUM(IF(reject_code = 'AC04',outward,0)) AS AC04
        ,SUM(IF(reject_code = 'AC06',outward,0)) AS AC06
        ,SUM(IF(reject_code = 'AC07',outward,0)) AS AC07
        ,SUM(IF(reject_code = 'OTHER',outward,0)) AS All_Other
        ,SUM(IF(reject_code = '9912',outward,0)) AS R9912
        ,SUM(IF(reject_code = '9910',outward,0)) AS R9910
        ,SUM(IF(reject_code = 'AM04',outward,0)) AS AM04
        ,SUM(IF(reject_code = 'DUPL',outward,0)) AS DUPL
        ,year
        ,month
    FROM (
        SELECT
            rejectCodes."reject code" AS reject_code,
            rejectCodes.outward,
            rejectCodes.year,
            rejectCodes.month
        FROM "tch"."participant_reject_codes" AS rejectCodes
        WHERE
            rejectCodes."reject code" IN (
                'DUPL','9912' ,'9910','AM04','AG01','AG03','NARR', '1100',
                'DS24','AC03','AC04','AC06','AC07','OTHER'
            )
    )
    GROUP BY year, month
),

Recon_Daily AS (
    SELECT
        SUM("number of inward transactions") AS Payment_Volume
        ,SUM("value of inward transactions") / 1000000 AS Payment_Value_mil
        ,SUM("value of inward transactions") / SUM("number of inward transactions") AS Avg_Txn_Amount
        ,Recon.year
        ,Recon.month
        ,Recon.day
    FROM
        "tch"."participant_recon" AS Recon
        LEFT JOIN Dates
            ON 1 = 1
    WHERE
        Recon.year = Dates.c_year
        AND Recon.month = Dates.c_month
        AND Recon.day = Dates.c_day
    GROUP BY
        Recon.year, Recon.month, Recon.day
),
Recon_Monthly AS (
    SELECT
        SUM("number of inward transactions") AS Payment_Volume
        ,SUM("value of inward transactions") / 1000000 AS Payment_Value_mil
        ,SUM("value of inward transactions")/SUM("number of inward transactions") AS Avg_Txn_Amount
        ,Recon.year
        ,Recon.month
    FROM
        "tch"."participant_recon" AS Recon
    GROUP BY
        Recon.year, Recon.month
),
Reject_Totals_Daily AS (
    SELECT
        SUM("total number of cr transfer transactions rejected-outward") AS Payment_Rejects
        ,rejectTotals.year
        ,rejectTotals.month
        ,rejectTotals.day
    FROM
        "tch"."participant_reject_totals" AS rejectTotals
        LEFT JOIN Dates
            ON 1 = 1
    WHERE
        rejectTotals.year = Dates.c_year
        AND rejectTotals.month = Dates.c_month
        AND rejectTotals.day = Dates.c_day
    GROUP BY
        rejectTotals.year, rejectTotals.month, rejectTotals.day
),
Reject_Totals_Monthly AS (
    SELECT
        SUM("total number of cr transfer transactions rejected-outward") AS Payment_Rejects
        ,rejectTotals.year
        ,rejectTotals.month
    FROM
        "tch"."participant_reject_totals" AS rejectTotals
    GROUP BY
        rejectTotals.year, rejectTotals.month
),

Daily_Rejects AS (
    SELECT
        business_date
        ,CONCAT(
            cast(Recon_Daily.month as varchar(2))
            , '/'
            , cast(Recon_Daily.day as varchar(2))
            , '/'
            , cast(Recon_Daily.year as varchar(4))
        ) as Date_Label
        ,Recon_Daily.Payment_Volume
        ,Recon_Daily.Payment_Value_mil
        ,Recon_Daily.Avg_Txn_Amount
        ,10000 * Reject_Totals_Daily.Payment_Rejects / (Recon_Daily.Payment_Volume + Reject_Totals_Daily.Payment_Rejects) AS Payment_Reject_Rate_Bps
        ,10000 * (R9910 + R9912 + DUPL + AM04) / (Recon_Daily.Payment_Volume + Reject_Totals_Daily.Payment_Rejects) AS Sending_To_Receiver_Bps
        ,10000 * (AG01 + AG03 + NARR + R1100 + DS24) / (Recon_Daily.Payment_Volume + Reject_Totals_Daily.Payment_Rejects) AS Receiving_Participant_Bps
        ,10000 * (Reject_Totals_Daily.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24)) / (Recon_Daily.Payment_Volume + Reject_Totals_Daily.Payment_Rejects) AS Account_Issue_Bps
        ,Reject_Totals_Daily.Payment_Rejects
        ,R9910 + R9912 + DUPL + AM04 AS Sending_To_Receiver
        ,R9910
        ,R9912
        ,DUPL
        ,AM04
        ,AG01 + AG03 + NARR + R1100 + DS24 AS Recieving_Participant
        ,AG01
        ,AG03
        ,NARR
        ,R1100
        ,DS24
        ,AC03 + AC04 + AC06 + AC07 AS Account_Issue
        ,AC03
        ,AC04
        ,AC06
        ,AC07
        ,Reject_Totals_Daily.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24 + AC03 + AC04 + AC06 + AC07) AS All_Other
    FROM
        Code_Stats_Daily
        INNER JOIN Recon_Daily
            ON Code_Stats_Daily.year = Recon_Daily.year
            AND Code_Stats_Daily.month = Recon_Daily.month
            AND Code_Stats_Daily.day = Recon_Daily.day
        INNER JOIN Reject_Totals_Daily
            ON Code_Stats_Daily.year = Reject_Totals_Daily.year
            AND Code_Stats_Daily.month = Reject_Totals_Daily.month
            AND Code_Stats_Daily.day = Reject_Totals_Daily.day
),

MTD_Rejects AS (
    SELECT
        business_date
        ,CONCAT(
            'MTD: '
            , cast(Recon_Monthly.year as varchar(4))
            , '-'
            , cast(Recon_Monthly.month as varchar(2))) as Date_Label
        ,Recon_Monthly.Payment_Volume
        ,Recon_Monthly.Payment_Value_mil
        ,Recon_Monthly.Avg_Txn_Amount
        ,10000 * Reject_Totals_Monthly.Payment_Rejects / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Payment_Reject_Rate_Bps
        ,10000 * (R9910 + R9912 + DUPL + AM04) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Sending_To_Receiver_Bps
        ,10000 * (AG01 + AG03 + NARR + R1100 + DS24) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Receiving_Participant_Bps
        ,10000 * (Reject_Totals_Monthly.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24)) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Account_Issue_Bps
        ,Reject_Totals_Monthly.Payment_Rejects
        ,R9910 + R9912 + DUPL + AM04 AS Sending_To_Receiver
        ,R9910
        ,R9912
        ,DUPL
        ,AM04
        ,AG01 + AG03 + NARR + R1100 + DS24 AS Recieving_Participant
        ,AG01
        ,AG03
        ,NARR
        ,R1100
        ,DS24
        ,AC03 + AC04 + AC06 + AC07 AS Account_Issue
        ,AC03
        ,AC04
        ,AC06
        ,AC07
        ,Reject_Totals_Monthly.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24 + AC03 + AC04 + AC06 + AC07) AS All_Other
    FROM
        Code_Stats_Monthly
        LEFT JOIN Dates
            ON 1 = 1
        INNER JOIN Recon_Monthly
            ON Code_Stats_Monthly.year = Recon_Monthly.year
            AND Code_Stats_Monthly.month = Recon_Monthly.month
        INNER JOIN Reject_Totals_Monthly
            ON Code_Stats_Monthly.year = Reject_Totals_Monthly.year
            AND Code_Stats_Monthly.month = Reject_Totals_Monthly.month
    WHERE
        Code_Stats_Monthly.year = Dates.c_year
        AND Code_Stats_Monthly.month = Dates.c_month
),

Prior_Month_Rejects AS (
    SELECT
        business_date
        ,CONCAT(
        'Prior Month: '
        , cast(Recon_Monthly.year as varchar(4))
        , '-'
        , cast(Recon_Monthly.month as varchar(2))) as Date_Label
        ,Recon_Monthly.Payment_Volume
        ,Recon_Monthly.Payment_Value_mil
        ,Recon_Monthly.Avg_Txn_Amount
        ,10000 * Reject_Totals_Monthly.Payment_Rejects / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Payment_Reject_Rate_Bps
        ,10000 * (R9910 + R9912 + DUPL + AM04) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Sending_To_Receiver_Bps
        ,10000 * (AG01 + AG03 + NARR + R1100 + DS24) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Receiving_Participant_Bps
        ,10000 * (Reject_Totals_Monthly.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24)) / (Recon_Monthly.Payment_Volume + Reject_Totals_Monthly.Payment_Rejects) AS Account_Issue_Bps
        ,Reject_Totals_Monthly.Payment_Rejects
        ,R9910 + R9912 + DUPL + AM04 AS Sending_To_Receiver
        ,R9910
        ,R9912
        ,DUPL
        ,AM04
        ,AG01 + AG03 + NARR + R1100 + DS24 AS Recieving_Participant
        ,AG01
        ,AG03
        ,NARR
        ,R1100
        ,DS24
        ,AC03 + AC04 + AC06 + AC07 AS Account_Issue
        ,AC03
        ,AC04
        ,AC06
        ,AC07
        ,Reject_Totals_Monthly.Payment_Rejects - (R9910 + R9912 + DUPL + AM04 + AG01 + AG03 + NARR + R1100 + DS24 + AC03 + AC04 + AC06 + AC07) AS All_Other
    FROM
        Code_Stats_Monthly
        LEFT JOIN Dates
            ON 1 = 1
        INNER JOIN Recon_Monthly
            ON Code_Stats_Monthly.year = Recon_Monthly.year
            AND Code_Stats_Monthly.month = Recon_Monthly.month
        INNER JOIN Reject_Totals_Monthly
            ON Code_Stats_Monthly.year = Reject_Totals_Monthly.year
            AND Code_Stats_Monthly.month = Reject_Totals_Monthly.month
    WHERE
        Code_Stats_Monthly.year = Dates.p_year
        AND Code_Stats_Monthly.month = Dates.p_month
)


SELECT * FROM Daily_Rejects
UNION
SELECT * FROM MTD_Rejects
UNION
SELECT * FROM Prior_Month_Rejects
;
