    SELECT
        SUM(IF(reject_code = 'AG01',outward,0)) AS AG01
        ,SUM(IF(reject_code = 'AG03',outward,0)) AS AG03
        ,SUM(IF(reject_code = 'NARR',outward,0)) AS NARR
        ,SUM(IF(reject_code = '1100',outward,0)) AS R1100
        ,SUM(IF(reject_code = 'DS24',outward,0)) AS DS24
        ,SUM(IF(reject_code = 'AC03',outward,0)) AS AC03
        ,SUM(IF(reject_code = 'AC04',outward,0)) AS AC04
        ,SUM(IF(reject_code = 'AC06',outward,0)) AS AC06
        ,SUM(IF(reject_code = 'AC07',outward,0)) AS AC07
        ,SUM(IF(reject_code = 'OTHER',outward,0)) AS All_Other
        ,SUM(IF(reject_code = '9912',outward,0)) AS R9912
        ,SUM(IF(reject_code = '9910',outward,0)) AS R9910
        ,SUM(IF(reject_code = 'AM04',outward,0)) AS AM04
        ,SUM(IF(reject_code = 'DUPL',outward,0)) AS DUPL
        ,year
        ,month
    FROM (
        SELECT
            rejectCodes."reject code" AS reject_code,
            rejectCodes.outward,
            rejectCodes.year,
            rejectCodes.month
        FROM "tch"."participant_reject_codes" AS rejectCodes
        WHERE
            rejectCodes."reject code" IN (
                'DUPL','9912' ,'9910','AM04','AG01','AG03','NARR', '1100',
                'DS24','AC03','AC04','AC06','AC07','OTHER'
            )
    )
    GROUP BY year, month;